this font is free version, just personal use. If you want download full version? please click the link below.

visit my store for more great fonts and freebies. https://creativemarket.com/alitdesign

http://graphicriver.net/user/alitsuarnegara/portfolio

http://www.myfonts.com/foundry/Alit_Design/

Find me on instagram for update my portfolio : https://www.instagram.com/alitsuarnegara/

www.alitdesign.net

for donation are very appreciated. my paypal id alit@crazyslug.net


=================================================================================
Introducing Raph Lanok Typeface which has a elegant hand lettering brush style. So it looks natural like a handmade, because Raph Lanok family have a more choice characters. This font is best used for your design project that has the concept of fun, brave and sporty. Can also be applied to the design of a logotype, header website, make some lettering a quote, t-shirt design etc.

Raph Lanok has three font styles are similar but a different character, namely is Raph Lanok Future and Raph Lanok Rusty but that you also get a Raph Lanok Swash of line fast brushed like a using font.

Raph Lanok Typeface deserve to be one of your fonts collections, because it is unique and has many options of alternative glyphs.

Product Content :

Raph Lanok Typeface (OTF, TTF Format & Web Font)
Raph Lanok Future Typeface (OTF, TTF Format & Web Font)
Raph Lanok Rusty Typeface (OTF, TTF Format & Web Font)
Raph Lanok Swash Typeface (OTF, TTF Format & Web Font)
Raph Lanok Character.pdf
Raph Lanok Future Character.pdf
Raph Lanok Rusty Character.pdf
Raph Lanok Swash Character.pdf
Features :

Character Set A-Z
Numerals & Punctuations (OpenType Standard)
Accents (Multilingual characters)
Standart Ligature
Stylistic Alternates
Apercase Alternates
SS01
SS02
SS03

